<ol class="list-group list-group-numbered my-4 shadow" id="categorys">
    <li class="list-group-item d-flex justify-content-between align-items-start">
        <div class="ms-2 me-auto">
            <div class="fw-bold">Acción</div>
            Cantidad disponible :
        </div>
        <span class="badge bg-primary rounded-pill">14</span>
    </li>
    <li class="list-group-item d-flex justify-content-between align-items-start">
        <div class="ms-2 me-auto">
            <div class="fw-bold">Aventura</div>
            Cantidad disponible :
        </div>
        <span class="badge bg-primary rounded-pill">14</span>
    </li>
    <li class="list-group-item d-flex justify-content-between align-items-start">
        <div class="ms-2 me-auto">
            <div class="fw-bold">Terror</div>
            Cantidad disponible :
        </div>
        <span class="badge bg-primary rounded-pill">14</span>
    </li>
</ol>