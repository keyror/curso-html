<div class="list-group my-4 shadow">
    <a href="#books" class="list-group-item list-group-item-action">Listado de libros</a>
    <a href="#categorys" class="list-group-item list-group-item-action">listado de categorias</a>
    <a href="#" class="list-group-item list-group-item-action">A third link item</a>
    <a href="#" class="list-group-item list-group-item-action">A fourth link item</a>
    <a href="#" class="list-group-item list-group-item-action">A disabled link item</a>
</div>