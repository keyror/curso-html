<div class="card shadow rounded text-center mt-4">
    <div class="card-header rounded bg-secondary bg-gradient text-white">
        <h4>Biografía.</h4>
    </div>
    <div class="card-body">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod nulla nihil eligendi magni quae ad assumenda! Incidunt, inventore sunt consequatur accusantium fugiat nesciunt magni eum molestiae recusandae aspernatur provident mollitia? Provident, animi? Voluptatum incidunt deserunt a veritatis mollitia unde laboriosam, quisquam ea veniam quidem illum cupiditate at alias, vitae id.</p>
    </div>
</div>