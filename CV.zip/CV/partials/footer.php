<div class="card-footer text-center">
    <small>Derechos reservados 2022</small>
</div>