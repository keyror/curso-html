<div class="list-group">
  <a href="#php" class="list-group-item list-group-item-action active" aria-current="true">
   Ir a php
  </a>
  <a href="#html" class="list-group-item list-group-item-action">Ir a HTML</a>
  <a href="#css" class="list-group-item list-group-item-action">Ir a CSS</a>
</div>